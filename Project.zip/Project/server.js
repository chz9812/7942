const express = require('express');
const app = express();

app.listen(7942, function () {
   console.log('listening on 7942')
});

app.get('/', function (요청, 응답) {
   응답.sendFile(__dirname + '/login.html')
});

app.get('/main', function (요청, 응답) {
   응답.sendFile(__dirname + '/main.html')
});

app.get('/board', function (요청, 응답) {
   응답.sendFile(__dirname + '/board.html')
});