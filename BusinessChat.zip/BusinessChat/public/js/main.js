const chatForm = document.getElementById('chat-form');
const chatMessages = document.querySelector('.chat-messages');
const roomName = document.getElementById('room-name');
const userList = document.getElementById('users');

// URL에서 사용자 이름과 방 가져 오기 
const { username, room } = Qs.parse(location.search, {
  ignoreQueryPrefix: true,
});

const socket = io();

// 채팅방 참여
socket.emit('joinRoom', { username, room });

// 사용자와 채팅룸
socket.on('roomUsers', ({ room, users }) => {
  outputRoomName(room);
  outputUsers(users);
});

// 서버 메시지
socket.on('message', (message) => {
  console.log(message);
  outputMessage(message);

  // 페이지 스크롤
  chatMessages.scrollTop = chatMessages.scrollHeight;
});

// 메시지 전송
chatForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // 메시지 내용
  let msg = e.target.elements.msg.value;

  msg = msg.trim();

  if (!msg) {
    return false;
  }

  // 서버로 메시지 보내기
  socket.emit('chatMessage', msg);

  // 입력 제거
  e.target.elements.msg.value = '';
  e.target.elements.msg.focus();
});

// 문서객체모델 메시지
function outputMessage(message) {
  const div = document.createElement('div');
  div.classList.add('message');
  const p = document.createElement('p');
  p.classList.add('meta');
  p.innerText = message.username;
  p.innerHTML += `<span>${message.time}</span>`;
  div.appendChild(p);
  const para = document.createElement('p');
  para.classList.add('text');
  para.innerText = message.text;
  div.appendChild(para);
  document.querySelector('.chat-messages').appendChild(div);
}

// 문서객체모델 룸이름
function outputRoomName(room) {
  roomName.innerText = room;
}

// 문서객체모델 사용자
function outputUsers(users) {
  userList.innerHTML = '';
  users.forEach((user) => {
    const li = document.createElement('li');
    li.innerText = user.username;
    userList.appendChild(li);
  });
}

//채팅방에서 나가기 전에 사용자에게 확인
document.getElementById('leave-btn').addEventListener('click', () => {
  const leaveRoom = confirm('채팅방을 나가시겠습니까?');
  if (leaveRoom) {
    window.location = '../index.html';
  } else {
  }
});
