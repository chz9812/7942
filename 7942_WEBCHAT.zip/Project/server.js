if (process.env.NODE_ENV !== 'production') {
   require('dotenv').config()
}

const { Socket } = require("dgram");
const express = require('express')
const http = require("http")
const app = express();
const path = require("path")
const bcrypt = require('bcrypt')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
const server = http.createServer(app)
const socketIO = require("socket.io")
const moment = require("moment")

const io = socketIO(server);

app.set('views', './views')
app.set('view engine', 'ejs')
app.use(express.static('public'))
app.use(express.urlencoded({ extended: true }))

const initializePassport = require('./passport-config')
initializePassport(
   passport,
   email => users.find(user => user.email === email),
   id => users.find(user => user.id === id)
)

const users = []

app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: false }))
app.use(flash())
app.use(session({
   secret: process.env.SESSION_SECRET,
   resave: false,
   saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))

//로그인
app.get('/login', function (req, res) {
   res.sendFile(__dirname + '/login.html')
});
app.post('/login', passport.authenticate('local', {
   successRedirect: '/main',
   failureRedirect: '/login',
   failureFlash: true
}))

//정보저장을 위한 회원가입 및 처음 화면
app.get('/', function (req, res) {
   res.sendFile(__dirname + '/register.html')
});
app.post('/', async (req, res) => {
   try {
      const hashedPassword = await bcrypt.hash(req.body.password, 10)
      users.push({
         id: Date.now().toString(),
         email: req.body.email,
         password: hashedPassword
      })
      res.redirect('/login')
   } catch {
      res.redirect('/')
   }
})

//로그아웃
app.delete('/logout', (req, res) => {
   req.logOut()
   res.redirect('/login')
})

function checkAuthenticated(req, res, next) {
   if (req.isAuthenticated()) {
      return next()
   }
   res.redirect('/login.html')
}

function checkAuthenticated(req, res, next) {
   if (req.isAuthenticated()) {
      return res.redirect('/')
   }
   next()
}

app.use(express.static(path.join(__dirname, "src")))
const PORT = process.env.PORT || 7942;

io.on("connection", (socket) => {
   socket.on("chatting", (data) => {
      const { name, msg } = data;
      io.emit("chatting", {
         name,
         msg,
         time: moment(new Date()).format("h:mm A")
      })
   })
})

app.get('/main', function (req, res) {
   res.sendFile(__dirname + '/main.html')
});


app.get('/chatting', function (req, res) {
   res.sendFile(__dirname + '/src/index.html')
});
app.get('/chatting1', function (req, res) {
   res.sendFile(__dirname + '/src/index1.html')
});
app.get('/chatting2', function (req, res) {
   res.sendFile(__dirname + '/src/index2.html')
});
app.get('/chatting3', function (req, res) {
   res.sendFile(__dirname + '/src/index3.html')
});
app.get('/chatting4', function (req, res) {
   res.sendFile(__dirname + '/src/index4.html')
});
app.get('/chatting5', function (req, res) {
   res.sendFile(__dirname + '/src/index5.html')
});

app.get('/chat', function (req, res) {
   res.sendFile(__dirname + '/chat.html')
});

const rooms = {}

app.get('/multi', (req, res) => {
   res.render('index', { rooms: rooms })
})

app.post('/room', (req, res) => {
   if (rooms[req.body.room] != null) {
      return res.redirect('/multi')
   }
   rooms[req.body.room] = { users: {} }
   res.redirect(req.body.room)
   // Send message that new room was created
   io.emit('room-created', req.body.room)
})

app.get('/:room', (req, res) => {
   if (rooms[req.params.room] == null) {
      return res.redirect('/multi')
   }
   res.render('room', { roomName: req.params.room })
})

server.listen(7942)

io.on('connection', socket => {
   socket.on('new-user', (room, name) => {
      socket.join(room)
      rooms[room].users[socket.id] = name
      socket.to(room).broadcast.emit('user-connected', name)
   })
   socket.on('send-chat-message', (room, message) => {
      socket.to(room).broadcast.emit('chat-message', { message: message, name: rooms[room].users[socket.id] })
   })
   socket.on('disconnect', () => {
      getUserRooms(socket).forEach(room => {
         socket.to(room).broadcast.emit('user-disconnected', rooms[room].users[socket.id])
         delete rooms[room].users[socket.id]
      })
   })
})

function getUserRooms(socket) {
   return Object.entries(rooms).reduce((names, [name, room]) => {
      if (room.users[socket.id] != null) names.push(name)
      return names
   }, [])
}